                    <div class="row">
                    	<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    		<div class="card bg-dark influencer-profile-data">
                    			<div class="card-body">
                    				<div class="row">
                    					<div class="col-xl-2 col-lg-4 col-md-4 col-sm-4 col-12">
                    						<div class="text-center">
                    							<img src="<?= base_url(); ?>assets/images/logos.png" alt="User Avatar"
                    								class="rounded-circle user-avatar-xxl">
                    						</div>
                    					</div>
                    					<div class="col-xl-10 col-lg-8 col-md-8 col-sm-8 col-12">
                    						<div class="user-avatar-info">
                    							<div class="m-b-20">
                    								<div class="user-avatar-name">
                    									<h2 class="mb-1 text-white"><?= PT_NAME; ?></h2>
                    								</div>
                    							</div>
                    							<div class="user-avatar-address">
                    								<p class="border-bottom pb-3">
                    									<span class="d-xl-inline-block d-block mb-2"><i
                    											class="fa fa-map-marker-alt mr-2 text-primary "></i>Jl.
                    										Pariwisata Nyeredep Aik Bual</span>
                    								</p>
                    								<div class="mt-3">
														<p>Selamat Datang Admin!<br>
                                                                      Ini adalah halaman khusus untuk admin yang mengelola website ini</p>
                    								</div>
                    							</div>
                    						</div>
                    					</div>
                    				</div>
                    			</div>
                    		</div>
                    	</div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- end content  -->
                    <!-- ============================================================== -->
                    <div class="row">
                    	<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    		<div class="row">
                    			<div class="col-6 col-lg-6 col-md-6">
                    				<div class="card bg-dark influencer-profile-data">
                    					<div class="card-body">
                    						<p>Sebaik-baik manusia adalah yang bermanfaat untuk manusia lainnya</p>
                    					</div>
                    				</div>
                    			</div>
								<div class="col-6 col-lg-6 col-md-6">
                    				<div class="card bg-dark influencer-profile-data">
                    					<div class="card-body">
                    						<p>Aku datang untuk belajar, dan aku pulang untuk membawa ilmu.</p>
                    					</div>
                    				</div>
                    			</div>
                    		</div>
                    	</div>
                    </div>
                    </div>
                    </div>
