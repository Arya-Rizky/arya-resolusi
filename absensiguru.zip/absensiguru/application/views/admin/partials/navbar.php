        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar bg-dark fixed-top">
                <a class="navbar-brand text-white" href="<?php echo base_url(); ?>karyawan"">
                    <img src="<?= base_url(); ?>assets/images/logos.png" alt="User Avatar" class="rounded-circle" width="45px">
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->